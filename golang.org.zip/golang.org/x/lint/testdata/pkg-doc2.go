// Test of package comment in an incorrect form.

// Some random package doc that isn't in the right form.
// MATCH /package comment should.*form.*"Package testdata .*"/
package testdata
